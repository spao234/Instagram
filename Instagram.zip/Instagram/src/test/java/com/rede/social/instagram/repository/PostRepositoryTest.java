package com.rede.social.instagram.repository;

import com.rede.social.instagram.model.Post;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataMongoTest
public class PostRepositoryTest {

    @Autowired
    private PostRepository postRepository;

    @Test
    void testFindByUsuarioId() {
        Post post1 = new Post("Texto 1", "url1.com", LocalDateTime.now(), "usuario1");
        Post post2 = new Post("Texto 2", "url2.com", LocalDateTime.now(), "usuario1");

        postRepository.save(post1);
        postRepository.save(post2);

        List<Post> posts = postRepository.findByUsuarioId("usuario1");

        assertEquals(2, posts.size());
    }
}
