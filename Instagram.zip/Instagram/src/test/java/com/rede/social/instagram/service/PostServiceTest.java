package com.rede.social.instagram.service;

import com.rede.social.instagram.model.Post;
import com.rede.social.instagram.repository.PostRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class PostServiceTest {

    @Mock
    private PostRepository postRepository;

    @InjectMocks
    private PostService postService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCriarPost() {
        Post post = new Post();
        post.setTexto("Meu primeiro post");
        post.setUsuarioId("123");

        when(postRepository.save(post)).thenReturn(post);

        Post resultado = postService.criarPost(post);

        assertEquals("Meu primeiro post", resultado.getTexto());
        assertEquals("123", resultado.getUsuarioId());
        verify(postRepository, times(1)).save(post);
    }

    @Test
    void testBuscarPostsPorUsuario() {
        Post post1 = new Post();
        post1.setUsuarioId("123");
        Post post2 = new Post();
        post2.setUsuarioId("123");

        when(postRepository.findByUsuarioId("123")).thenReturn(List.of(post1, post2));

        List<Post> resultado = postService.buscarPostsPorUsuario("123");

        assertEquals(2, resultado.size());
        verify(postRepository, times(1)).findByUsuarioId("123");
    }
}
