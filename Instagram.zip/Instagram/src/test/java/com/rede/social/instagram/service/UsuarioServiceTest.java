@SpringBootTest
public class UsuarioServiceTest {

    @MockBean
    private UsuarioRepository usuarioRepository;

    @Autowired
    private UsuarioService usuarioService;

    @Test
    public void testCriarUsuario() {
        Usuario usuario = new Usuario();
        usuario.setNome("João");

        when(usuarioRepository.save(usuario)).thenReturn(usuario);

        Usuario criado = usuarioService.criarUsuario(usuario);

        assertEquals("João", criado.getNome());
    }
}
