package com.rede.social.instagram.controller;

import com.rede.social.instagram.model.Usuario;
import com.rede.social.instagram.service.UsuarioService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class UsuarioControllerTest {

    @Mock
    private UsuarioService usuarioService;

    @InjectMocks
    private UsuarioController usuarioController;

    UsuarioControllerTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCriarUsuario() {
        Usuario usuario = new Usuario();
        usuario.setNome("Maria");

        when(usuarioService.criarUsuario(usuario)).thenReturn(usuario);

        ResponseEntity<Usuario> response = usuarioController.criarUsuario(usuario);

        assertEquals(201, response.getStatusCodeValue());
        assertEquals("Maria", response.getBody().getNome());
        verify(usuarioService, times(1)).criarUsuario(usuario);
    }

    @Test
    void testBuscarUsuario() {
        Usuario usuario = new Usuario();
        usuario.setEmail("maria@example.com");

        when(usuarioService.buscarPorEmail("maria@example.com")).thenReturn(usuario);

        Usuario resultado = usuarioController.buscarUsuario("maria@example.com");

        assertEquals("maria@example.com", resultado.getEmail());
        verify(usuarioService, times(1)).buscarPorEmail("maria@example.com");
    }
}
