package com.rede.social.instagram.service;

import com.rede.social.instagram.model.Post;
import com.rede.social.instagram.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostService {

    @Autowired
    private PostRepository postRepository;

    public Post criarPost(Post post) {
        return postRepository.save(post);
    }

    public List<Post> buscarPostsPorUsuario(String usuarioId) {
        return postRepository.findByUsuarioId(usuarioId);
    }

    public List<Post> buscarPostsPorTexto(String texto) {
        return postRepository.findByTextoContaining(texto);
    }
}
