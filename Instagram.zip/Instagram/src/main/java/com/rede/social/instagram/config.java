package com.rede.social.instagram;

public class config {
}
