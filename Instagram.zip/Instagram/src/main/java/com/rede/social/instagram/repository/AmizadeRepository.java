package com.rede.social.instagram.repository;

import com.rede.social.instagram.model.Amizade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.rede.social.instagram.model.Usuario;

import java.util.List;

@Repository
public interface AmizadeRepository extends JpaRepository<Amizade, Long> {
    List<Usuario> findAmigos(Long usuarioId);
}
