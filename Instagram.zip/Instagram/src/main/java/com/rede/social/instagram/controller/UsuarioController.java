package com.rede.social.instagram.controller;

import com.rede.social.instagram.model.Usuario;
import com.rede.social.instagram.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/criar")
    public Usuario criarUsuario(@RequestBody Usuario usuario) {
        return usuarioService.criarUsuario(usuario);
    }

    @GetMapping("/buscar/{email}")
    public Usuario buscarUsuario(@PathVariable String email) {
        return usuarioService.buscarPorEmail(email);
    }
}
