package com.rede.social.instagram.service;

public class PostServiceImpl extends PostService {
}
