package com.rede.social.instagram.repository;

import com.rede.social.instagram.model.Curtida;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CurtidaRepository extends JpaRepository<Curtida, Long> {

    // Você pode adicionar métodos personalizados, se necessário
    long countByPostId(Long postId); // Conta o número de curtidas em um post específico
}
