package com.rede.social.instagram.controller;

import com.rede.social.instagram.model.Post;
import com.rede.social.instagram.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/posts")
public class PostController {

    @Autowired
    private PostService postService;

    @PostMapping("/criar")
    public Post criarPost(@RequestBody Post post) {
        return postService.criarPost(post);
    }

    @GetMapping("/usuario/{usuarioId}")
    public List<Post> buscarPostsPorUsuario(@PathVariable String usuarioId) {
        return postService.buscarPostsPorUsuario(usuarioId);
    }
}
