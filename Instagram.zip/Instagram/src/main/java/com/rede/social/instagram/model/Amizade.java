package com.rede.social.instagram.model;

import jakarta.persistence.*;

@Entity
public class Amizade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_solicitante_id", nullable = false)
    private Usuario solicitante;

    @ManyToOne
    @JoinColumn(name = "usuario_destinatario_id", nullable = false)
    private Usuario destinatario;

    private Boolean aceita;

    // Construtor padrão
    public Amizade() {}

    // Construtor com parâmetros (opcional)
    public Amizade(Usuario solicitante, Usuario destinatario, Boolean aceita) {
        this.solicitante = solicitante;
        this.destinatario = destinatario;
        this.aceita = aceita;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Usuario getSolicitante() {
        return solicitante;
    }

    public void setSolicitante(Usuario solicitante) {
        this.solicitante = solicitante;
    }

    public Usuario getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(Usuario destinatario) {
        this.destinatario = destinatario;
    }

    public Boolean getAceita() {
        return aceita;
    }

    public void setAceita(Boolean aceita) {
        this.aceita = aceita;
    }
}
