package com.rede.social.instagram.repository;

public interface MongoRepository<T, T1> {
}
